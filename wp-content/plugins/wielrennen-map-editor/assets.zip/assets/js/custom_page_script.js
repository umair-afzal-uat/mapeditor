/* ---------------------------------------------------------------- SUPPORTED --- */


jQuery(document).ready(function($) {
    
  
	
	$(window).scroll(function() {    
        var body = document.body,
        html = document.documentElement;
        var elmnt = document.querySelector(".elementor-5749");
        var elmnt1 = document.querySelector(".elementor-6002");
        var colophon = document.getElementById("colophon");
        if(elmnt != null) {

            if(scroll < (elmnt.offsetHeight - colophon.offsetHeight - 50)) {

                $("#all_pages_heading_fixed").addClass("stick_heading_box");
                
            } else {
                $("#all_pages_heading_fixed").removeClass("stick_heading_box");
            }
        }
        if(elmnt1 != null) {
          
            if(scroll < (elmnt1.offsetHeight - colophon.offsetHeight)) {

            $("#all_pages_heading_fixed").addClass("stick_heading_box");

            } else {
            $("#all_pages_heading_fixed").removeClass("stick_heading_box");
            }
        }
    });
    $(window).scroll(function() {    
        if ($(window).scrollTop() + $(window).height() >= $(document).height() - 200) {
            $("#about_heading_fixed").removeClass("stick_heading_box");

        } else {
             $("#about_heading_fixed").addClass("stick_heading_box");

        }
    });
    $(document).on('click','.woocommerce-message.hidden-notice',function() {
        $(this).css('display','none');
    });
     $(document).on('click','.woocommerce-message.hidden-notice',function() {
        $(this).css('display','none');
    });
     $(document).on('click','.woocommerce-info.mollie-instructions',function() {
        $(this).css('display','none');
    });
      $(document).on('click','.woocommerce-notice--success.woocommerce-thankyou-order-received',function() {
        $(this).css('display','none');
    });
});
